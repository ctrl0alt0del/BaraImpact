import { h, render } from "preact";
import { UnityPrimitiveProvider } from "./primitives/UnityPrimitiveProvider";
import { StaminaMeter } from "./ui/componetns/StaminaMeter";
import { RenderTextureSurface } from "./ui/componetns/system/RenderTextureSurface";
import { Image } from "UnityEngine/UIElements";
import { Resources, Texture2D } from "UnityEngine";

declare const puerts: { $typeof: (t: any) => any };
const text = Resources.Load("tiles", puerts.$typeof(Texture2D)) as Texture2D;
console.log("Loaded texture:", text);
//chess tiles to test blitted RTs
render(
  <RenderTextureSurface width={1024} height={1024}>
    <UnityPrimitiveProvider>
      <image image={text} style={{ position: "absolute", top: 0, left: 0 }} />
    </UnityPrimitiveProvider>
  </RenderTextureSurface>,
  document.body
);
