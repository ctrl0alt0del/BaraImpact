// RenderTextureSurface.tsx
import { h, render, Fragment, ComponentChildren } from "onejs-preact";
import { useEffect, useState } from "preact/hooks";
import {
  Vector2,
  GameObject,
  RenderTexture,
  ColorSpace,
  QualitySettings,
  Experimental,
  Resources,
} from "UnityEngine";
import {
  UIDocument,
  PanelSettings,
  PanelScaleMode,
  Label,
  StyleColor,
} from "UnityEngine/UIElements";
import { useBlittedRT } from "@/hooks/useBlittedRT";
import { useUIPyramidBillboardPose2D } from "@/hooks/useUIPyramidBillboard";
import { Document } from "OneJS/Dom";
import { DocumentWrapper } from "onejs-core/dom/document";
import { useObjectByName } from "@/hooks/useObject";
import { ScriptEngine } from "OneJS";

const GraphicsFormat = Experimental.Rendering.GraphicsFormat;
const UObject = CS.UnityEngine.Object;
/* ------------------------------------------------------------------ */
export interface SurfaceProps {
  width?: number;
  height?: number;
  /** 0-1 viewport location the billboard should “live” at */
  anchor01?: Vector2;
  children?: ComponentChildren;
}

export const RenderTextureSurface = ({
  width = 1024,
  height = 1024,
  anchor01 = new Vector2(0.1, 0.3), // default: upper-centre of screen
  children,
}: SurfaceProps) => {
  /* 1️⃣ create & expose the source RenderTexture ------------------------- */
  const [srcRT, setSrcRT] = useState<RenderTexture | null>(null);
  const scriptEngineObj = useObjectByName("ScriptEngine");
  useEffect(() => {
    if (!scriptEngineObj) {
      console.warn(
        "ScriptEngine object not found, cannot create RenderTextureSurface."
      );
      return;
    }
    const fmt =
      QualitySettings.activeColorSpace === ColorSpace.Linear
        ? GraphicsFormat.R8G8B8A8_SRGB
        : GraphicsFormat.R8G8B8A8_UNorm;

    const rt = new RenderTexture(width, height, 0);
    rt.graphicsFormat = fmt;
    rt.name = `HUD_RT_${width}x${height}`;
    rt.Create();
    setSrcRT(rt);

    /* hidden UIDocument that renders `children` into the RT */
    const go = new GameObject("HUD_RT_Doc");
    const doc = go.AddComp(UIDocument);
    const ps = CS.UnityEngine.ScriptableObject.CreateInstance(
      "PanelSettings"
    ) as PanelSettings;
    ps.name = "HUD_RT_PanelSettings";
    ps.scaleMode = PanelScaleMode.ConstantPixelSize;
    ps.targetTexture = rt;
    doc.panelSettings = ps;
    const root = doc.rootVisualElement;
    const domRoot = new Document(root, scriptEngineObj.GetComp(ScriptEngine));
    const domRootWrapper = new DocumentWrapper(domRoot);
    render(<Fragment>{children}</Fragment>, domRootWrapper.body);

    return () => {
      console.log("Cleaning up RenderTextureSurface...");
      render(null, domRootWrapper.body);
      rt.Release();
      UObject.Destroy(go);
    };
  }, [scriptEngineObj]); // ← only once

  /* 2️⃣ get yaw / pitch / roll from your working hook -------------------- */
  const pose = useUIPyramidBillboardPose2D(anchor01);

  /* 3️⃣ warp srcRT through your shader hook ------------------------------ */
  const warpedRT = useBlittedRT(srcRT, {
    width,
    height,
    yaw: pose?.yaw ?? 0,
    pitch: pose?.pitch ?? 0,
    roll: pose?.roll ?? 0,
    pivot: pose?.pivot01 ?? new Vector2(0.5, 0.5), // default pivot at centre
    // keep the rest (scale / persp) default inside the hook
  });

  /* 4️⃣ return a normal UITK <image> showing the warped RT --------------- */
  return warpedRT ? (
    <image
      image={warpedRT}
      style={{
        width: `${width}px`,
        height: `${height}px`,
        alignSelf: "center",
      }}
    />
  ) : null;
};
