// @/ui/RadialGauge.tsx
import { h } from "preact";
import { useContext, useMemo } from "preact/hooks";
import { GaugeThemeCtx } from "@/ui/theme";
import { PrimitiveCtx } from "@/primitives/PrimitiveContext";
import { Mathf } from "UnityEngine";

interface Props {
  current: number; // current resource
  max: number; // max resource
  /** tick step in resource units (e.g. 20 stamina) */
  tickInterval: number;
  size?: number;
}

/** platform-agnostic gauge that works with raw resource values */
export function RadialGauge({
  current,
  max,
  tickInterval,
  size = 96,
}: Readonly<Props>) {
  const P = useContext(PrimitiveCtx);
  const T = useContext(GaugeThemeCtx);
  /* memo everything that only changes if size/theme/interval changes */
  const memo = useMemo(() => {
    const r = size / 2;
    const stroke = T.width;
    const centre = r;

    /* --------- 1 ▸ build an array of remaining-stamina levels --------- */
    const levels: number[] = [0];
    for (let s = max - tickInterval; s > 0; s -= tickInterval) {
      levels.push(s); // e.g. [35, 25, 15, 5]
    }
    /* --------- 2 ▸ convert every level into a tick line --------------- */
    const ticks = levels.map((stam, idx) => {
      //  full circle * fraction remaining – 90° so 0 starts at 12 o’clock
      const angle = (stam / max) * Mathf.PI * 2 - Mathf.PI / 2;
      const cos = Mathf.Cos(angle);
      const sin = Mathf.Sin(angle);
      return P.Line({
        x1: centre + cos * r, // tip flush with ring
        y1: centre + sin * r,
        x2: centre + cos * r * 0.8, // 20 % shorter
        y2: centre + sin * r * 0.8,
        width: stroke * 0.4,
        color: T.tick,
      });
    });

    return { r, stroke, ticks };
  }, [size, T, max, tickInterval, P]);

  /* convert current / max to sweep angle */
  const fillAngle = (current / max) * 2 * Mathf.PI;

  /* shared abs style is memo-safe because inputs are constants */
  const abs = { position: "absolute", left: "0px", top: "0px" };
  return (
    <div style={{ width: size, height: size, position: "relative" }}>
      {/* background ring */}
      {P.Circle({
        radius: memo.r,
        width: memo.stroke,
        color: T.back,
        style: abs,
      })}
      {/* fill ring */}
      {P.Circle({
        radius: memo.r,
        width: memo.stroke,
        color: T.fill,
        angle: fillAngle,
        style: abs,
      })}
      {memo.ticks}
    </div>
  );
}
